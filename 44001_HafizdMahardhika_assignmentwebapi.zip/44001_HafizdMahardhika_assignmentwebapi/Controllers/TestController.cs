﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace _44001_Hafizd_TrainingWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        public static readonly int[] randomInt = new[]
        {
            1,3,4,5,6,7,8,9,10,11,12,13
        };

        [HttpGet]
        [Route("GetIntegerStatic")]
        public IEnumerable<int> getInteger()
        {
            return randomInt;
        }
    }
}
