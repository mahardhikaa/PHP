﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using _44001_Hafizd_TrainingWebAPI.DatabaseContent;

namespace _44001_Hafizd_TrainingWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeacherController : ControllerBase
    {
        private readonly TeacherDB _db;

        public TeacherController(TeacherDB db)
        {
            _db = db;
        }

        [HttpPost]
        [Route("InsertTeacher")]
        public async Task<IResult> InsertTeacher(Teacher model)
        {
            _db.teacherData.Add(model);
            await _db.SaveChangesAsync();
            return Results.Created($"GetTeacher/{model.Id}", model);
        }

        [HttpGet]
        [Route("GetTeacher")]
        public async Task<IEnumerable<Teacher>> GetTeacher()
        {
            return await _db.teacherData.ToListAsync();
        }

        [HttpGet]
        [Route("GetTeacherById")]
        public async Task<IResult> GetTeacherById(int id)
        {
            var std = await _db.teacherData.FindAsync(id);
            if (std == null)
            {
                return Results.NotFound();
            }
            return Results.Ok(std);
        }

        [HttpPut]
        [Route("UpdateTeacher")]
        public async Task<IResult> UpdateTeacher(int id, string specialization, int age)
        {
            var std = await _db.teacherData.FindAsync(id);
            if (std == null)
            {
                return Results.NotFound();
            }
            std.Specialization = specialization;
            std.Age = age;
            await _db.SaveChangesAsync();
            return Results.Ok(std);
        }

        [HttpDelete]
        [Route("DeleteTeacher")]
        public async Task<IResult> DeleteTeacher(int id)
        {
            var std = await _db.teacherData.FindAsync(id);
            if (std == null)
            {
                return Results.NotFound();
            }
            _db.Remove(std);
            await _db.SaveChangesAsync();
            return Results.Ok(std);
        }
    }
}
