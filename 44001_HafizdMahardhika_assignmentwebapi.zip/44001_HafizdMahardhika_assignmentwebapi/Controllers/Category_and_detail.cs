﻿using _44001_Hafizd_TrainingWebAPI.DatabaseContent;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections;

namespace _44001_Hafizd_TrainingWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Category_and_detail : ControllerBase
    {
        private readonly School _dbDetail;

        public Category_and_detail(School dbDetail)
        {
            _dbDetail = dbDetail;
        }

        [HttpGet]
        [Route("GetDetailCategory")]
        public async Task<IResult> GetDetailCategory(int id)
        {
            var std = await (from detail in _dbDetail.detailData
                             join category in _dbDetail.categoryData on detail.categoryId equals category.Id
                             join student in _dbDetail.detailStudent on detail.studentId equals student.Id
                             where category.Id == id
                             select new
                             {
                                 Id = detail.Id,
                                 categoryId = category.Id,
                                 categoryCode = category.categoryCode,
                                 categoryDesc = category.categoryDescription,
                                 studentId = student.Id,
                                 Name = student.name,
                                 Score = student.score

                             }).ToListAsync();

            return Results.Ok(std);
        }
    }
}
