﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using _44001_Hafizd_TrainingWebAPI.DatabaseContent;

namespace _44001_Hafizd_TrainingWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class studentController : ControllerBase
    {
        private readonly StudentDb _db;

        public studentController(StudentDb db)
        {
            _db = db;
        }

        [HttpPost]
        [Route("InsertStudent")]
        public async Task<IResult> InsertStudent(Student model)
        {
            _db.studentData.Add(model);
            await _db.SaveChangesAsync();
            return Results.Created($"GetStudent/{model.Id}", model);
        }

        [HttpGet]
        [Route("GetStudent")]
        public async Task<IEnumerable<Student>> GetStudent()
        {
            return await _db.studentData.ToListAsync();
        }

        [HttpGet]
        [Route("GetStudentById")]
        public async Task<IResult> GetStudentById(int id)
        {
            var std = await _db.studentData.FindAsync(id);
            if(std == null)
            {
                return Results.NotFound();
            }
            return Results.Ok(std);
        }

        [HttpPut]
        [Route("UpdateStudentScore")]
        public async Task<IResult> UpdateStudentScore(int id, decimal score, string name)
        {
            var std = await _db.studentData.FindAsync(id);
            if (std == null)
            {
                return Results.NotFound();
            }
            std.score = score;
            std.name = name; 
            await _db.SaveChangesAsync();
            return Results.Ok(std);
        }

        [HttpDelete]
        [Route("DeleteStudent")]
        public async Task<IResult> DeleteStudent(int id)
        {
            var std = await _db.studentData.FindAsync(id);
            if (std == null)
            {
                return Results.NotFound();
            }
            _db.Remove(std);
            await _db.SaveChangesAsync(); 
            return Results.Ok(std);
        }


    }
}
