﻿using _44001_Hafizd_TrainingWebAPI.DatabaseContent;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace _44001_Hafizd_TrainingWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CRUD_Category_Detail : ControllerBase
    {
        private readonly School _db;

        public CRUD_Category_Detail(School db)
        {
            _db = db;
        }

        [HttpPost]
        [Route("InsertCategory")]
        public async Task<IResult> InsertCategory(Category model)
        {
            _db.categoryData.Add(model);
            await _db.SaveChangesAsync();
            return Results.Created($"GetCategory/{model.Id}", model);
        }

        [HttpPost]
        [Route("InsertDetail")]
        public async Task<IResult> InsertDetail(DetailCategory model)
        {
            _db.detailData.Add(model);
            await _db.SaveChangesAsync();
            return Results.Created($"GetDetail/{model.Id}", model);
        }

        [HttpGet]
        [Route("GetCategory")]
        public async Task<IEnumerable<Category>> GetCategory()
        {
            return await _db.categoryData.ToListAsync();
        }

        [HttpGet]
        [Route("GetDetail")]
        public async Task<IEnumerable<DetailCategory>> GetDetail()
        {
            return await _db.detailData.ToListAsync();
        }

        [HttpGet]
        [Route("GetCategoryById")]
        public async Task<IResult> GetCategoryById(int id)
        {
            var std = await _db.categoryData.FindAsync(id);
            if (std == null)
            {
                return Results.NotFound();
            }
            return Results.Ok(std);
        }

        [HttpGet]
        [Route("GetDetailById")]
        public async Task<IResult> GetDetailById(int id)
        {
            var std = await _db.detailData.FindAsync(id);
            if (std == null)
            {
                return Results.NotFound();
            }
            return Results.Ok(std);
        }

        [HttpPut]
        [Route("UpdateCategory")]
        public async Task<IResult> UpdateCategory(int id, string categoryCode, string categoryDesc)
        {
            var std = await _db.categoryData.FindAsync(id);
            if (std == null)
            {
                return Results.NotFound();
            }
            std.categoryCode = categoryCode;
            std.categoryDescription = categoryDesc;
            await _db.SaveChangesAsync();
            return Results.Ok(std);
        }

        [HttpPut]
        [Route("UpdateDetail")]
        public async Task<IResult> UpdateDetail(int id, int studentId, int categoryId)
        {
            var std = await _db.detailData.FindAsync(id);
            if (std == null)
            {
                return Results.NotFound();
            }
            std.studentId = studentId;
            std.categoryId = categoryId;
            await _db.SaveChangesAsync();
            return Results.Ok(std);
        }

        [HttpDelete]
        [Route("DeleteCategory")]
        public async Task<IResult> DeleteCategory(int id)
        {
            var std = await _db.categoryData.FindAsync(id);
            if (std == null)
            {
                return Results.NotFound();
            }
            _db.Remove(std);
            await _db.SaveChangesAsync();
            return Results.Ok(std);
        }

        [HttpDelete]
        [Route("DeleteDetail")]
        public async Task<IResult> DeleteDetail(int id)
        {
            var std = await _db.detailData.FindAsync(id);
            if (std == null)
            {
                return Results.NotFound();
            }
            _db.Remove(std);

            await _db.SaveChangesAsync();
            return Results.Ok(std);
        }
    }
}
