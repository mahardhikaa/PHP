﻿using _44001_Hafizd_TrainingWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace _44001_Hafizd_TrainingWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class scoreController : ControllerBase
    {
        private static readonly List<scoreModel> scoreModels = new List<scoreModel> 
        { 
            new scoreModel
            {
                Name = "Hafizd",
                Score = 80
            },
            new scoreModel
            {
                Name = "Mahardhika",
                Score = 100
            },
            new scoreModel
            {
                Name = "Faris",
                Score = 90
            },
            new scoreModel
            {
                Name = "Yukla",
                Score = 95
            },
            new scoreModel
            {
                Name = "Masputra",
                Score = 70
            },
        };

        [HttpGet]
        [Route("getScoreStudent")]

        public IEnumerable<scoreModel> Get()
        {
            return scoreModels;
        }

    }
}
