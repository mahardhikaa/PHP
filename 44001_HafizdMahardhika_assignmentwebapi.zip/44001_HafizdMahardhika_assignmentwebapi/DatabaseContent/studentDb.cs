﻿using Microsoft.EntityFrameworkCore;

namespace _44001_Hafizd_TrainingWebAPI.DatabaseContent
{
    public class Student
    {
        public int Id { get; set; }
        public string name { get; set; }
        public bool isPassed { get; set; }
        public decimal score { get; set; }
    }

    public class StudentDb : DbContext
    {
        public StudentDb(DbContextOptions<StudentDb> option) : base(option) {  }
        public DbSet<Student> studentData => Set<Student>();
    }
}
