﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace _44001_Hafizd_TrainingWebAPI.DatabaseContent
{
    public class Category
    {
        public int Id { get; set; }
        public string categoryCode { get; set; }
        public string categoryDescription { get; set; }
        public int teacherId { get; set; }
    }
    public class DetailCategory
    {
        public int Id { get; set; }
        public int categoryId { get; set; }
        public Category Category { get; set; }
        public int studentId { get; set; }
        public Student Student { get; set; }
    }

    public class School : DbContext
    {
        public School(DbContextOptions<School> option) : base(option) { }
        public DbSet<DetailCategory> detailData => Set<DetailCategory>();
        public DbSet<Category> categoryData => Set<Category>();
        public DbSet<Student> detailStudent => Set<Student>();
    }
}
