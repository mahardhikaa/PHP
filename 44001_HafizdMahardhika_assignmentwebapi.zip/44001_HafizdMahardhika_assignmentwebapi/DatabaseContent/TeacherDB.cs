﻿using Microsoft.EntityFrameworkCore;

namespace _44001_Hafizd_TrainingWebAPI.DatabaseContent
{
    public class Teacher
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Specialization { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }

        public bool isPassed { get; set; }
    }

    public class TeacherDB : DbContext
    {
        public TeacherDB(DbContextOptions<TeacherDB> option) : base(option) { }
        public DbSet<Teacher> teacherData => Set<Teacher>();
    }
}
