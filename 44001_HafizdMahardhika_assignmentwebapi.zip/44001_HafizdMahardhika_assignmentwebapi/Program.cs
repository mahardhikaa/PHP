using _44001_Hafizd_TrainingWebAPI.DatabaseContent;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<StudentDb>(opt => opt.UseInMemoryDatabase("Student"));
builder.Services.AddDbContext<TeacherDB>(opt => opt.UseInMemoryDatabase("Teacher"));
builder.Services.AddDbContext<School>(opt => opt.UseInMemoryDatabase("Category"));
builder.Services.AddDbContext<School>(opt => opt.UseInMemoryDatabase("DetailCategory"));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
