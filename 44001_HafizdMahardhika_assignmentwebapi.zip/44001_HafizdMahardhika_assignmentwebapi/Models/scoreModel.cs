﻿namespace _44001_Hafizd_TrainingWebAPI.Models
{
    public class scoreModel
    {
        public string Name { get; set; }
        public int Score { get; set; }
    }
}
